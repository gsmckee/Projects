﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WWHD
{
    public partial class Form1 : Form
    {
        Cannonball round;// declare object of child class Cannonball
        protected Timer tmr;// used to increment position of object
        public int user_xVel = 0;
        public int user_yVel = 0;//Store user inputed velocity for object along x and y coordinates.
        
        // starting positon, velocity for direction, and angle.
        //protected int x, y, velX, velY, angle; 

        public Bitmap objImg;// store .png to be referenced
        
        public Form1()
        {
            
            round = new Cannonball(10, 0, 20, 45);
            objImg = Properties.Resources.Standard1;
            tmr = new Timer();
            tmr.Interval = 16;
            tmr.Tick += Tmr_Tick;
            InitializeComponent();
            cbOrdList.SelectedIndex = 0;

            //Remove flicker from paint object.
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer
                | ControlStyles.UserPaint, true);
            UpdateStyles();

            //Enforce form to fit full screen.
            this.WindowState = FormWindowState.Maximized;
        }

        private void Tmr_Tick(object sender, EventArgs e)// Timer 
        {
            
            round.moveObj(0.032f, user_xVel, user_yVel);
            float speed = (float)Math.Sqrt(round.VelX * round.VelX + round.VelY * round.VelY);
            Text = round.X + ", " + round.Y + ", Vel: " + round.VelX + ", " + round.VelY + " Speed " + speed;
            
            Invalidate();
        }

        private void btnFire_Click(object sender, EventArgs e)
        {
            tmr.Start();
        }

        private void btnEnterCoords_Click(object sender, EventArgs e)
        {
            bool usrY;
            bool usrX;


            usrX = int.TryParse(tbVelX.Text, out user_xVel);
            usrY = int.TryParse(tbVelY.Text, out user_yVel);
            if (usrX == false || usrY == false)
            {                
                lblU_inputError.Visible = true;
                if (usrX == false && usrY == false)
                {
                    lblU_inputError.Text = "X, Y coords require whole integers.";
                    //round.VelX = 200;
                    //round.VelY = 900;
                    
                }
                else if (usrX == false)
                {
                    lblU_inputError.Text = "X coords require whole integers.";
                    user_yVel = int.Parse(tbVelY.Text);
                    //round.VelX = 200;
                    //round.VelY = int.Parse(tbVelY.Text);
                }
                else
                {
                    lblU_inputError.Text = "Y coords require whole integers.";
                    user_xVel = int.Parse(tbVelX.Text);
                    //round.VelX = int.Parse(tbVelX.Text);
                    //round.VelY = 900;
                }
            }
            else
            {
                user_xVel = int.Parse(tbVelX.Text);
                user_yVel = int.Parse(tbVelY.Text);
                //round.VelX = int.Parse(tbVelX.Text);
                //round.VelY = int.Parse(tbVelY.Text);
            }

        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            tmr.Stop();
        }


        //Display desired images and user interface elements.
        protected override void OnPaint(PaintEventArgs e)
        {
            //base.OnPaint(e);
            int imgHeight = (objImg.Height) / 2;
            int imgWidth = (objImg.Width) / 2;
            int xPic = (int)round.X - imgWidth;
            int yPic = (int)(this.Height - 40 -round.Y) - imgHeight;
            Graphics pic = e.Graphics;
            pic.Clear(Color.Green);
            pic.ResetTransform();
            pic.TranslateTransform(xPic, yPic);
            pic.DrawImage(objImg, new Point(0, 0));
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            
        }



        // Take action on selected index of combo box.

        //private void cbOrdList_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    default.selectedIndex(1);// set to selected text of combo box
        //}


        // Tie resource image to selected combo box string.
        //protected Image getImg(string s)
        //{
        //    Image img;
        //    switch (s)
        //    {
        //        case "Circular":
        //            img = Properties.Resources.CannonBall;
        //            break;
        //        case "Bullet":
        //            img = Properties.Resources.Projectile;
        //            break;
        //        case "Grenade":
        //            img = Properties.Resources.Grenade;
        //            break;
        //        case "Missile":
        //            img = Properties.Resources.Missile;
        //            break;
        //        case "Mortar":
        //            img = Properties.Resources.Mortar;
        //            break;
        //        case "Rocket":
        //            img = Properties.Resources.Rocket;
        //            break;
        //        default : img = null;
        //            break;  
        //    }
        //    return img;
        //}
    }
}
