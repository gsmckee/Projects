﻿using System;

public enum Shape
{
	Circular, Bullet, Grenade
} 

