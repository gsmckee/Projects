#include "PolynomialType.h"

#ifndef _DERIVATIVE



int Main()
{

	return 0;
}

#endif 